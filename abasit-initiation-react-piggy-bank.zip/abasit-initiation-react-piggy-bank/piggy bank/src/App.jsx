import React, { useState } from "react";
import "./App.css";

function table() {
  const [tasks, setTasks] = useState([]);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const handleNameChange = (event) => {
    setName(event.target.value);
  };
  const handleDescriptionChange = (event) => {
    setDescription(event.target.value);
  };
  const handlePriceChange = (event) => {
    setPrice(event.target.value);
  };
  const handleSubmit = (event) => {
    event.preventDefault();

    if (name.trim() !== "" && price.trim() !== "") {
      const newTask = {
        name: name,
        description: description,
        price: parseFloat(price),
      };

      setTasks([...tasks, newTask]);
      setName("");
      setDescription("");
      setPrice("");
    } else {
      alert("Name and price can not be null");
    }
  };
  const handleDelete = (index, newlist) => {
    newlist((prevItems) => {
      const newlist = [...prevItems];
      newlist.splice(index, 1);
      return newlist;
    });
  };
  const calculateTotalPrice = () => {
    const total = tasks.reduce((acc, task) => acc + task.price, 0);
    return total;
  };

  return (
    <>
      <center>
        <h1>My Piggy Bank</h1>
      </center>
      <div>
        <table className="table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Description</th>
              <th>Price</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {tasks.map((task, index) => (
              <tr key={index}>
                <td>{task.name}</td>
                <td>{task.description}</td>
                <td>{task.price}</td>
                <td>
                  <button
                    className="delete-button"
                    onClick={() => handleDelete(index, setTasks)}
                  >
                    {" "}
                    Delete{" "}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <p>
          {" "}
          <b>Total:</b>
          <b>{calculateTotalPrice()}</b>
        </p>
      </div>
      <center>
        <h2>Add New Expense</h2>
        {/* <img src="../../src/assets/ezgif.com-crop.jpg" /> */}
      </center>
      <form onSubmit={handleSubmit} className="expense-form">
        <tr>
          {" "}
          <input
            className="expense-form input "
            type="text"
            value={name}
            onChange={handleNameChange}
            placeholder="Name"
          />
        </tr>
        <tr>
          <textarea
            className="expense-form textarea "
            type="text"
            value={description}
            onChange={handleDescriptionChange}
            placeholder="Description"
          />{" "}
        </tr>
        <tr>
          <input
            className="expense-form input "
            type="number"
            value={price}
            onChange={handlePriceChange}
            placeholder="Price"
          />
        </tr>
        <button className="expense-form input " type="submit">
          Submit
        </button>
      </form>
    </>
  );
}

export default table;
